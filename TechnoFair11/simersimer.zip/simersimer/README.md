# SimerSimer

Description:

```
Chatbot SimerSimer merupakan teman chat lucu & rceh sekali.

URL : http://ctf.technofair11.com:1812
API : http://ctf.technofair11.com:1204

Author: necl
```

Flag : `TechnoFair11{s1m3rs1imer_y0u_mus7_bipas_1t}`
