<?php
// Pemalas Setting